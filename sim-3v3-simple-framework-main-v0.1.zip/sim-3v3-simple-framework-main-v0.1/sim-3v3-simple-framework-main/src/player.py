"""Player:单个机器人的控制 handle —— 用户可直接编辑这个类。

平台原语(set_velocity / kick / release_kick / request_mode / get_up)委托给注入的
``_backend``(framework 层);状态 property(pose / mode / is_fallen / penalty)从
``self.context`` 或 backend 读。

走位行为(walk_to / face_to / ensure_ready)也是 Player 方法:它们本质是"对本
球员下命令的动词",且未来加迟滞/避障需要的跨帧状态可直接挂 ``self``。纯坐标计算
(dist / angle_to / 球门坐标等)才放 utils/geom。

实例跨整场比赛存活;``self.context`` 每帧被框架覆写。用户想加自己的拐棍方法直接
在这里加。
"""

from __future__ import annotations

import logging
import math
from typing import TYPE_CHECKING

from .framework.types import Context, Penalty, Pose2D
from .framework import debugdraw

from .param import *
from .utils.geom import (
    angle_to,
    ball_in_opponent_penalty_area,
    clamp,
    dist,
    normalize_angle,
    opponent_goal,
    own_goal,
    own_goal_area_center,
)
from .utils.obstacles import collect_obstacles
from .utils.path_planner import plan_global_path

if TYPE_CHECKING:
    from .framework.config import SoccerConfig


__all__ = ["Player"]


_log = logging.getLogger(__name__)

def _heading_clearance(
    px: float, py: float, heading: float, obstacles: list,
) -> float:
    """用于局部避障。沿 (px,py) 朝 ``heading`` 的 lookahead 射线,到最近障碍的余量(dist - radius)。

    只考虑**前方**(投影 t>0)的障碍;身后 / 侧后的障碍不挡这个方向,跳过——否则贴近
    任何障碍(哪怕正后方)都会把所有方向的余量拉低,误判"全堵"。
    无障碍返回 inf;越大越空,负值表示会撞。
    """
    ux, uy = math.cos(heading), math.sin(heading)
    min_clear = math.inf
    for obs in obstacles:
        t = (obs.x - px) * ux + (obs.y - py) * uy
        if t <= 0.0:
            continue                      # 障碍在身后/侧后,不挡此方向
        if t > PLAN_LOOKAHEAD:
            t = PLAN_LOOKAHEAD
        nx, ny = px + ux * t, py + uy * t
        clear = math.hypot(obs.x - nx, obs.y - ny) - obs.radius
        if clear < min_clear:
            min_clear = clear
    return min_clear


def _behind_ball(
    ball_x: float, ball_y: float, aim: tuple[float, float], offset: float,
) -> tuple[float, float]:
    """用于计算站位。球在 球→``aim`` 连线上的"后方"点:从球沿【背离 aim】方向退 ``offset`` 米。

    追球走位目标用它:球落在机器人与 ``aim`` 之间,到位时天然对准 aim 方向。
    aim 与球重合(退化)时,方向不定,直接返回球位。
    """
    dx, dy = aim[0] - ball_x, aim[1] - ball_y
    d = math.hypot(dx, dy)
    if d < 1e-6:
        return (ball_x, ball_y)
    ux, uy = dx / d, dy / d              # 球指向 aim 的单位向量
    return (ball_x - ux * offset, ball_y - uy * offset)   # 背离 aim 退 offset


class Player:
    """单个球员的 handle。可以在这里加入新的技术动作。
    """

    def __init__(
        self,
        player_id: int,
        config: "SoccerConfig",
        _backend: object | None,
    ) -> None:
        self.id: int = player_id
        self.config: "SoccerConfig" = config
        self._backend = _backend           # 机器人控制接口的包装，通常不用改
        self.context: Context | None = None

        # 当前高层动作名(仅供可视化/调试)。策略分派层每帧写入;有子状态的动作
        # (如 guard)在方法内部细化。可视化 pass 读它标注文字,见 main.py。
        self.action: str = "init"

        # SDK 缓存字段,框架后台会自动更新
        self._mode: str | None = None
        self._fall_down_state: str | None = None

        # 避障绕行侧记忆(跨帧;None=当前无绕行)
        self._avoid_side: float | None = None

        # 踢球迟滞状态(跨帧)
        self._kicking: bool = False
        # 出脚前调整计时(跨帧;requirement 2):对手较远时先稳住再踢
        self._kick_settle_since: float | None = None
        self._kick_settle_ball: tuple[float, float] | None = None
        self._settled: bool = False        # 本次控球是否已完成 0.4s 调整(一次性)

        # block/guard 的跨帧迟滞状态
        self._block_pressing: bool = False
        self._guard_threatened: bool = False
        # 门线撞球进门迟滞状态
        self._goal_line_push: bool = False
        # support 卡住后临时转 attack 的跨帧状态
        self._support_last_pos: tuple[float, float] | None = None
        self._support_stationary_since: float | None = None
        self._support_last_update_at: float | None = None

    # ------------------------------------------------------------------
    # 状态读取
    # ------------------------------------------------------------------

    @property
    def is_kicking(self) -> bool:
        """当前是否处于踢球状态。"""
        return self._kicking

    @property
    def pose(self) -> Pose2D | None:
        ctx = self.context
        if ctx is None:
            return None
        robot = ctx.teammates.get(self.id)
        return None if robot is None else robot.pose

    @property
    def mode(self) -> str | None:
        if self._backend is not None:
            return self._backend.mode
        return self._mode

    @property
    def is_fallen(self) -> bool:
        return self.fall_down_state not in (None, "normal")

    @property
    def fall_down_state(self) -> str | None:
        if self._backend is not None:
            return getattr(self._backend, "fall_down_state", None)
        return self._fall_down_state

    @property
    def penalty(self) -> Penalty:
        ctx = self.context
        if ctx is None or ctx.game is None:
            return Penalty.NONE
        state = ctx.game.get_player_state(self.config.team_id, self.id)
        return Penalty.NONE if state is None else state.penalty

    @property
    def is_penalized(self) -> bool:
        return self.penalty != Penalty.NONE

    # ------------------------------------------------------------------
    # 底盘控制
    # ------------------------------------------------------------------

    def set_velocity(self, vx: float, vy: float, vyaw: float) -> None:
        if self._backend is None:
            _log.debug(
                "player %d set_velocity vx=%.3f vy=%.3f vyaw=%.3f (no backend)",
                self.id, vx, vy, vyaw,
            )
            return
        self._backend.set_velocity(vx, vy, vyaw)

    def stop(self) -> None:
        self.release_kick()
        self.set_velocity(0.0, 0.0, 0.0)

    # ------------------------------------------------------------------
    # 踢球
    # ------------------------------------------------------------------

    def kick(
        self,
        kick_direction: float | None = None,
        power: float = KICK_POWER_DEFAULT,
    ) -> None:
        pose = self.pose
        if pose is None:
            _log.warning("player %d kick skipped: pose unknown", self.id)
            return

        ball = self.context.ball if self.context is not None else None
        if ball is None:
            _log.warning("player %d kick skipped: ball unknown", self.id)
            return

        if kick_direction is None:
            kick_plan = self.plan_kick()
            if kick_plan is None:
                _log.warning("player %d kick skipped: kick plan unavailable", self.id)
                return
            kick_direction, power = kick_plan

        if self._backend is None:
            _log.debug(
                "player %d kick ball=(%.3f, %.3f) dir=%.3f (no backend)",
                self.id, ball.x, ball.y, kick_direction,
            )
            return
        # 场地坐标 → 体坐标(用当前 pose)
        dx = ball.x - pose.x
        dy = ball.y - pose.y
        cos_t = math.cos(pose.theta)
        sin_t = math.sin(pose.theta)
        ball_x_body = dx * cos_t + dy * sin_t
        ball_y_body = -dx * sin_t + dy * cos_t
        kick_direction = normalize_angle(kick_direction)
        direction_body = normalize_angle(kick_direction - pose.theta)
        power_clamped = max(KICK_POWER_MIN, min(KICK_POWER_MAX, power))
        self._kicking = True
        self._backend.kick(direction_body, power_clamped, ball_x_body, ball_y_body)

    def plan_kick(self) -> tuple[float, float] | None:
        """计算踢球方向和力度。

        从当前球位踢向对方球门中心,力度 2.0。
        返回 ``(kick_direction, kick_power)``;球或上下文不可用时返回 None。
        """
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return None

        kick_target = opponent_goal(ctx)
        kick_direction = angle_to(ball.x, ball.y, *kick_target)
        kick_target = self._goal_target_for_direction(kick_direction)
        kick_power = (
            KICK_POWER_BACKFIELD if self._in_backfield()
            else KICK_POWER_DEFAULT
        )

        self._draw_kick_target(kick_target)
        return kick_direction, kick_power

    def _goal_target_for_direction(
        self, kick_direction: float,
    ) -> tuple[float, float]:
        """把射门方向投到对方门线上,用于可视化踢球目标。"""
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return (0.0, 0.0)

        dx = math.cos(kick_direction)
        if dx <= 1e-6:
            return opponent_goal(ctx)
        goal_x = ctx.field.length / 2.0
        t = max(0.0, (goal_x - ball.x) / dx)
        return (goal_x, ball.y + math.sin(kick_direction) * t)

    def _in_backfield(self) -> bool:
        """球在我方后场时,默认踢球加大力度。"""
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return False
        # own_penalty_edge_x = -ctx.field.length / 2.0 + ctx.field.penalty_area_length
        # return ball.x < own_penalty_edge_x
        return ball.x < 0

    def _draw_kick_target(self, target: tuple[float, float]) -> None:
        """以 X 标出 plan_kick 选择的踢球目标。"""
        from .framework import debugdraw

        x, y = target
        s = KICK_TARGET_MARK_SIZE_M
        debugdraw.line(
            [(x - s, y - s), (x + s, y + s)],
            rgb=(1.0, 0.0, 1.0), ns="kick_target",
        )
        debugdraw.line(
            [(x - s, y + s), (x + s, y - s)],
            rgb=(1.0, 0.0, 1.0), ns="kick_target",
        )

    def release_kick(self) -> None:
        self._kicking = False  # 清除踢球迟滞标志(取消方块显示)
        self._settled = False  # 离开踢球状态:下次再次控球需重新做 0.4s 调整
        if self._backend is None:
            _log.debug("player %d release_kick (no backend)", self.id)
            return
        self._backend.release_kick()

    def kick_can_score(self, kick_direction: float) -> bool:
        """判断从当前球位按 ``kick_direction`` 踢,直线轨迹是否能进对方球门。
        """
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return False

        goal_x = ctx.field.length / 2.0
        dx = math.cos(kick_direction)
        dy = math.sin(kick_direction)
        if dx <= 1e-6:
            return False

        half_goal = ctx.field.goal_width / 2.0
        if half_goal <= 0.0:
            return False
        if ball.x >= goal_x:
            y_at_goal = ball.y
        else:
            t = (goal_x - ball.x) / dx
            if t < 0.0:
                return False
            y_at_goal = ball.y + dy * t
        return -half_goal <= y_at_goal <= half_goal

    # ------------------------------------------------------------------
    # 慢操作（同步接口异步调取，使得不阻塞）
    # ------------------------------------------------------------------

    def request_mode(self, mode: str) -> None:
        if self._backend is None:
            _log.debug("player %d request_mode -> %s (no backend)", self.id, mode)
            return
        self._backend.request_mode(mode)

    def get_up(self) -> None:
        if self._backend is None:
            _log.debug("player %d get_up (no backend)", self.id)
            return
        self._backend.get_up()

    # ------------------------------------------------------------------
    # 走位
    # ------------------------------------------------------------------

    def ensure_ready(self) -> bool:
        """活性自理:摔倒→起身,非 walk→切模式(都异步、不产生移动)。

        返回本帧是否可执行动作(True=已就绪)。
        """
        if self.is_fallen:
            self.get_up()
            return False
        if self.mode != "walk":
            self.request_mode("walk")
            return False
        return True

    def face_to(self, target_theta: float) -> None:
        """原地转向到目标朝向。"""
        if self.pose is None:
            self.stop()
            return
        err = normalize_angle(target_theta - self.pose.theta)
        self.set_velocity(0.0, 0.0, self._angular(err))

    def walk_to(
        self,
        target: tuple[float, float],
        *,
        face: float | None = None,
        avoid_ball: bool = False,
        avoid_robots: bool = False,
        arrive_dist: float = ARRIVE_DIST,
        max_linear: float = MAX_LINEAR,
    ) -> bool:
        """走向目标点。返回是否已到达。

        避障(局部规划器,简化版 VFH):``avoid_ball`` / ``avoid_robots`` 开启时,把
        球 / 机器人 / 球门结构收集成圆形障碍,在机器人周围扫一圈候选方向,选"最朝
        目标 + 前方 ``PLAN_LOOKAHEAD`` 内不撞障碍"的方向前进。能处理多障碍、凹形
        结构和对称冲突,比单障碍绕行 / 势场排斥稳。

        行走两种模式:近距离全向,远距离转身-走。``face`` 指定到达/近距离时的朝向。
        """
        self.release_kick() # 踢球状态下，走位会被覆盖，先取消踢球状态
        pose = self.pose
        if pose is None:
            self.stop()
            return False

        tx, ty = target
        dx = tx - pose.x
        dy = ty - pose.y
        distance = math.hypot(dx, dy)

        if distance < arrive_dist:
            # 已到达:按需转到目标朝向
            if face is not None:
                err = normalize_angle(face - pose.theta)
                if abs(err) > 0.1:
                    self.set_velocity(0.0, 0.0, self._angular(err))
                else:
                    self.stop()
            else:
                self.stop()
            return True

        # 规划:默认全局 A*,找不到路时退回旧局部规划。
        goal_dir = math.atan2(dy, dx)
        planned_path: list[tuple[float, float]] | None = None
        waypoint: tuple[float, float] | None = None
        if (avoid_ball or avoid_robots) and self.context is not None:
            obstacles = collect_obstacles(
                self.context, self.id,
                ball=avoid_ball, robots=avoid_robots,
                goals=(avoid_ball or avoid_robots),
            )
            if USE_GLOBAL_PATH_PLANNER:
                planned_path = plan_global_path(
                    self.context,
                    (pose.x, pose.y),
                    (tx, ty),
                    obstacles,
                )
                if planned_path is not None:
                    waypoint = self._path_waypoint(pose, planned_path)
                    heading = angle_to(pose.x, pose.y, waypoint[0], waypoint[1])
                else:
                    heading = self._plan_heading(pose, goal_dir, obstacles)
            else:
                heading = self._plan_heading(pose, goal_dir, obstacles)
        else:
            heading = goal_dir

        # 可视化:目标点(绿)、到目标连线(灰)、规划朝向(黄箭头)、
        # 前方探测射线(青,长度=lookahead;规划器"看"的范围,无 path/途径点概念)
        from .framework import debugdraw
        debugdraw.point(tx, ty, rgb=(0.0, 1.0, 0.0), scale=0.15, ns="target")
        debugdraw.line([(pose.x, pose.y), (tx, ty)], rgb=(0.4, 0.4, 0.4), ns="to_target")
        if planned_path is not None and len(planned_path) >= 2:
            debugdraw.line(planned_path, rgb=(0.2, 0.8, 1.0), ns="global_path")
        if waypoint is not None:
            debugdraw.point(
                waypoint[0], waypoint[1],
                rgb=(0.2, 0.8, 1.0), scale=0.12, ns="global_waypoint",
            )
        debugdraw.arrow(
            pose.x, pose.y,
            pose.x + math.cos(heading) * 0.6, pose.y + math.sin(heading) * 0.6,
            rgb=(1.0, 1.0, 0.0), ns="heading",
        )
        debugdraw.line(
            [(pose.x, pose.y),
             (pose.x + math.cos(heading) * PLAN_LOOKAHEAD,
              pose.y + math.sin(heading) * PLAN_LOOKAHEAD)],
            rgb=(0.0, 0.8, 0.8), ns="lookahead",
        )

        if distance <= OMNI_DIST:
            # 近距离:全向行走,沿 heading 平移,同时转向 face
            wdx, wdy = math.cos(heading) * distance, math.sin(heading) * distance
            cos_t, sin_t = math.cos(pose.theta), math.sin(pose.theta)
            vx = LINEAR_GAIN * (wdx * cos_t + wdy * sin_t)
            vy = LINEAR_GAIN * (-wdx * sin_t + wdy * cos_t)
            speed = math.hypot(vx, vy)
            if speed > max_linear:
                vx *= max_linear / speed
                vy *= max_linear / speed
            vyaw = (
                self._angular(normalize_angle(face - pose.theta))
                if face is not None else 0.0
            )
            self.set_velocity(vx, vy, vyaw)
        else:
            # 远距离:转身-走-转身,朝 heading
            angle_err = normalize_angle(heading - pose.theta)
            if abs(angle_err) > TURN_THRESHOLD:
                self.set_velocity(0.0, 0.0, self._angular(angle_err))
            else:
                vx = clamp(
                    LINEAR_GAIN * distance * math.cos(angle_err), 0.0, max_linear,
                )
                self.set_velocity(vx, 0.0, self._angular(angle_err))
        return False

    def _path_waypoint(
        self, pose: Pose2D, path: list[tuple[float, float]],
    ) -> tuple[float, float]:
        """Pick a short lookahead waypoint from a planned global path."""
        if not path:
            return (pose.x, pose.y)
        prev = (pose.x, pose.y)
        points = path[1:] if len(path) > 1 else path
        for point in points:
            seg_len = dist(prev[0], prev[1], point[0], point[1])
            if seg_len >= GLOBAL_PATH_LOOKAHEAD_M:
                ratio = GLOBAL_PATH_LOOKAHEAD_M / max(seg_len, 1e-6)
                return (
                    prev[0] + (point[0] - prev[0]) * ratio,
                    prev[1] + (point[1] - prev[1]) * ratio,
                )
            prev = point
        return path[-1]

    def _plan_heading(
        self, pose: Pose2D, goal_dir: float, obstacles: list,
    ) -> float:
        """扫候选方向,选最朝目标且前方够空的方向;都不够空时返回最空的那个。

        候选按偏离目标方向 ``|offset|`` 从小到大试;先试哪一侧由 player_id 奇偶决定,
        用来打破两人同侧避让的对称。
        """
        sign_first = 1.0 if self.id % 2 == 0 else -1.0
        best_h = goal_dir
        best_clear = -math.inf

        offsets = [0.0]
        k = 1
        while k * PLAN_STEP <= PLAN_MAX_OFFSET + 1e-9:
            offsets.append(sign_first * k * PLAN_STEP)
            offsets.append(-sign_first * k * PLAN_STEP)
            k += 1

        for off in offsets:
            h = goal_dir + off
            clear = _heading_clearance(pose.x, pose.y, h, obstacles)
            if clear >= PLAN_CLEARANCE:
                return h
            if clear > best_clear:
                best_clear, best_h = clear, h
        return best_h

    # ------------------------------------------------------------------
    # 高层动作(策略在 main.py 里直接调这些)
    # ------------------------------------------------------------------


    def block_path_projection(
        self, opponent_id: int,
    ) -> tuple[float, float, float, float] | None:
        """自己到 对手→球 线段的垂足:返回 (x, y, 垂距, 线段参数 t)。"""
        ctx = self.context
        pose = self.pose
        ball = ctx.ball if ctx is not None else None
        opponent = ctx.opponents.get(opponent_id) if ctx is not None else None
        if ctx is None or pose is None or ball is None or opponent is None:
            return None
        if opponent.pose is None:
            return None

        ax, ay = opponent.pose.x, opponent.pose.y
        bx, by = ball.x, ball.y
        vx, vy = bx - ax, by - ay
        length2 = vx * vx + vy * vy
        if length2 < 1e-6:
            return None

        raw_t = ((pose.x - ax) * vx + (pose.y - ay) * vy) / length2
        t = clamp(raw_t, 0.0, 1.0)
        tx = ax + vx * t
        ty = ay + vy * t
        return tx, ty, dist(pose.x, pose.y, tx, ty), raw_t

    def _nearest_opponent_dist(self) -> float:
        """自己到最近对手的直线距离;无对手可见(或自己 pose 未知)时返回 inf。"""
        ctx = self.context
        pose = self.pose
        if ctx is None or pose is None:
            return math.inf
        nearest = math.inf
        for opp in ctx.opponents.values():
            if opp.pose is None:
                continue
            nearest = min(nearest, dist(pose.x, pose.y, opp.pose.x, opp.pose.y))
        return nearest

    def attack(self, kick_target: tuple[float, float] | None = None) -> None:
        """追球射门。踢向 ``kick_target``(默认对方球门中心)。

        踢球迟滞:距球 ≤ ENTER 进入踢球;进入后距球 > EXIT 才退出(EXIT > ENTER),
        防边界抖动。不避障——正常拼抢要直取球。追球目标设在【球后方】(球→球门连线
        上、背离球门退 ``CHASE_BEHIND_M``),到位时天然对准射门方向。

        两个进阶行为:
        - requirement 3:球进入对方禁区时,追球步速在上限上 +``PENALTY_AREA_SPEED_BONUS``,
          抢在官方 AI 站位封堵前完成收官。
        - requirement 2:进踢球范围后,若最近对手距**自己** >= ``KICK_SETTLE_OPP_DIST_M``
          (没被贴身逼抢),先稳住 ``KICK_SETTLE_TIME_S`` 秒做对位调整再出脚;对手逼近
          时跳过调整直接踢,避免被抢断。
        """
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None or self.pose is None:
            self.stop()
            return
        if kick_target is None:
            kick_target = opponent_goal(ctx)

        d = dist(self.pose.x, self.pose.y, ball.x, ball.y)
        in_kick_range = d <= (KICK_EXIT_M if self._kicking else KICK_ENTER_M)

        if not in_kick_range:
            # 追球:球在对方禁区时提速收官(requirement 3)。
            self._reset_kick_settle()
            self.release_kick()
            max_linear = (
                MAX_LINEAR + PENALTY_AREA_SPEED_BONUS
                if ball_in_opponent_penalty_area(ctx)
                else MAX_LINEAR
            )
            self.walk_to(
                _behind_ball(ball.x, ball.y, kick_target, CHASE_BEHIND_M),
                max_linear=max_linear,
            )
            return

        # 已进入踢球范围。
        self._kicking = True

        # requirement 2:对手不贴近且本次控球尚未调整过时,先做 KICK_SETTLE_TIME_S
        # 秒对位调整再出脚;调整完成后置 _settled,后续帧直接踢(一次性,不反复喘振)。
        if (
            not self._settled
            and self._nearest_opponent_dist() >= KICK_SETTLE_OPP_DIST_M
        ):
            now = ctx.now
            if self._kick_settle_since is None:
                self._kick_settle_since = now
                self._kick_settle_ball = (ball.x, ball.y)
            ball_moved = (
                self._kick_settle_ball is not None
                and dist(ball.x, ball.y, *self._kick_settle_ball)
                > KICK_SETTLE_BALL_MOVE_M
            )
            if now - self._kick_settle_since < KICK_SETTLE_TIME_S and not ball_moved:
                # 调整中:停住底盘,仅微调朝向对准出球方向,不触球。
                self.action = "attack:settle"
                kick_dir = angle_to(ball.x, ball.y, *kick_target)
                err = normalize_angle(kick_dir - self.pose.theta)
                self.set_velocity(0.0, 0.0, self._angular(err))
                return
            # 调整完成(计时到或球被碰动):标记本次控球已调整,再去踢。
            self._settled = True

        # 对手贴近或调整完成:立即出脚(带遮挡判断选点:门中心被挡则选门框内空档)。
        self._reset_kick_settle()
        shot_target = self.choose_shot_target()
        self._draw_kick_target(shot_target)
        kick_direction = angle_to(ball.x, ball.y, *shot_target)
        kick_power = (
            KICK_POWER_BACKFIELD if self._in_backfield() else KICK_POWER_DEFAULT
        )
        self.kick(kick_direction, kick_power)

    def _reset_kick_settle(self) -> None:
        self._kick_settle_since = None
        self._kick_settle_ball = None

    def _segment_blocked(
        self, x0: float, y0: float, x1: float, y1: float, pad: float = 0.15,
    ) -> bool:
        """线段 (x0,y0)->(x1,y1) 是否被可见对手挡住(点到线段横向距离 < 对手半径+pad)。"""
        ctx = self.context
        if ctx is None:
            return False
        vx, vy = x1 - x0, y1 - y0
        seg2 = vx * vx + vy * vy
        if seg2 < 1e-6:
            return False
        seg = math.sqrt(seg2)
        ux, uy = vx / seg, vy / seg
        for opp in ctx.opponents.values():
            if opp.pose is None:
                continue
            rx, ry = opp.pose.x - x0, opp.pose.y - y0
            t = rx * ux + ry * uy
            if t <= 0.0 or t >= seg:
                continue
            lateral = abs(rx * uy - ry * ux)
            if lateral < OPPONENT_RADIUS + pad:
                return True
        return False

    def choose_shot_target(self) -> tuple[float, float]:
        """选择射门目标点:优先对方门中心,若被对手遮挡则在门框内挑选未被遮挡的偏移点。"""
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None:
            return (0.0, 0.0)
        gx, gy = opponent_goal(ctx)
        half = ctx.field.goal_width / 2.0 * 0.6
        for off in (0.0, half, -half, half * 0.5, -half * 0.5):
            tx, ty = gx, off
            if not self._segment_blocked(ball.x, ball.y, tx, ty):
                return (tx, ty)
        return (gx, gy)

    def approach_and_kick(
        self,
        aim: tuple[float, float],
        power: float,
        settle_time: float = SET_PLAY_SETTLE_TIME_S,
    ) -> None:
        """定位球主罚:先绕到球后方并正对 ``aim``,停顿 ``settle_time`` 秒调整后再出脚。

        - 未就位(太远 / 不在球后 / 横向偏出):只走位,不踢;
        - 就位后:停稳底盘微调朝向,累计 ``settle_time``(球被碰动则提前)后一次性踢向
          ``aim``,力度 ``power``。用于边线球 / 角球主罚。
        """
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        if ctx is None or ball is None or self.pose is None:
            self.stop()
            return

        kick_dir = angle_to(ball.x, ball.y, aim[0], aim[1])
        cos_k, sin_k = math.cos(kick_dir), math.sin(kick_dir)
        rx, ry = self.pose.x - ball.x, self.pose.y - ball.y
        behind = rx * cos_k + ry * sin_k        # <0 在球的后方(背离 aim 侧)
        lateral = abs(-rx * sin_k + ry * cos_k)
        d = math.hypot(rx, ry)

        ready = (
            d <= KICK_ENTER_M
            and behind <= SET_PLAY_FRONT_MARGIN
            and lateral <= SET_PLAY_LATERAL_TOL
        )
        if not ready:
            # 绕到球后并对准 aim(不避球,便于贴上去)。
            self._reset_kick_settle()
            self.release_kick()
            self.walk_to(
                _behind_ball(ball.x, ball.y, aim, CHASE_BEHIND_M),
                face=kick_dir,
            )
            return

        # 已就位:停顿调整后出脚。
        now = ctx.now
        if self._kick_settle_since is None:
            self._kick_settle_since = now
            self._kick_settle_ball = (ball.x, ball.y)
        ball_moved = (
            self._kick_settle_ball is not None
            and dist(ball.x, ball.y, *self._kick_settle_ball) > SET_PLAY_SETTLE_BALL_MOVE_M
        )
        if now - self._kick_settle_since < settle_time and not ball_moved:
            self.action = "set_play:settle"
            err = normalize_angle(kick_dir - self.pose.theta)
            self.set_velocity(0.0, 0.0, self._angular(err))
            return
        self._reset_kick_settle()
        self.kick(kick_dir, power)

    def hold_away_from_ball(self, target: tuple[float, float] | None = None) -> None:
        """对方开球 / 系统摆球:不触球,始终与球保持 >= ``BALL_CLEARANCE_OPP_RESTART_M``。

        - 先 ``release_kick``,确保不会去踢球;
        - 若自己当前已在安全半径内,先沿 球→自己 反方向退到安全距离外;
        - 否则走 ``target``;若 ``target`` 落在球的禁区内,则把它沿 球→target 方向推出到
          安全半径外,保证到位后也不碰球。
        """
        ctx = self.context
        ball = ctx.ball if ctx is not None else None
        pose = self.pose
        if ctx is None or ball is None or pose is None:
            self.stop()
            return
        self.release_kick()
        safe = BALL_CLEARANCE_OPP_RESTART_M
        # 落点留出额外余量,越过避障里球的膨胀障碍(半径+余量 ≈ 0.6m)以保证可到达;
        # 该距离仍 >= 0.5m,满足"不触控球"约束。
        stand_off = safe + GLOBAL_OBSTACLE_MARGIN_M + 0.05

        # 自己太靠近球:先沿 球→自己 反方向退到安全距离外。
        d_self = dist(pose.x, pose.y, ball.x, ball.y)
        if d_self < safe:
            ux = (pose.x - ball.x) / max(d_self, 1e-6)
            uy = (pose.y - ball.y) / max(d_self, 1e-6)
            self.walk_to(
                (ball.x + ux * stand_off, ball.y + uy * stand_off),
                avoid_ball=True,
            )
            return

        if target is None:
            self.stop()
            return

        # 目标点若在球的安全圈内,推出到安全半径外(退化到己方半场方向)。
        dx = target[0] - ball.x
        dy = target[1] - ball.y
        td = math.hypot(dx, dy)
        if td < stand_off:
            if td < 1e-6:
                target = (ball.x - stand_off, ball.y)
            else:
                target = (
                    ball.x + dx / td * stand_off,
                    ball.y + dy / td * stand_off,
                )
        self.walk_to(target, avoid_ball=True, avoid_robots=True)

    def guard(self) -> None:
        """守门:站小禁区中央待命

        无 pose(未就位)时退回站小禁区中央。
        """
        home = own_goal_area_center(self.context) if self.context is not None else None
        if home is None or self.pose is None:
            self.action = "guard:stop"
            self.stop()
            return

        ball = self.context.ball if self.context is not None else None

        # 待命朝向:朝球(便于快速反应);球不可见则朝对方门方向(默认 0)。
        face = 0.0
        if GUARD_FACE_BALL and ball is not None:
            face = angle_to(
                self.pose.x, self.pose.y, ball.x, ball.y,
            )

        self.action = "guard:home"
        debugdraw.point(
            home[0], home[1], rgb=(0.0, 0.6, 1.0), scale=0.2, ns="guard_home",
        )
        self.walk_to(home, face=face, avoid_ball=True, avoid_robots=True)

    def support(self) -> None:
        """支援:站在 球→己方门中心 连线上距球 ``SUPPORT_DIST_M`` 处补防。

        站位点在球与己方门之间的封堵线上。
        """
        ctx = self.context
        if ctx is None:
            self.stop()
            return

        ball = self.context.ball
        gx, gy = own_goal(ctx)
        bx, by = (ball.x, ball.y)
        dx, dy = gx - bx, gy - by
        d = math.hypot(dx, dy)
        if d < 1e-6:
            ux, uy = -1.0, 0.0
        else:
            ux, uy = dx / d, dy / d
        along = min(SUPPORT_DIST_M, d)
        tx = bx + ux * along
        ty = by + uy * along

        # 不越过己方底线(x >= 门线 + 0.3),横向夹进场内
        half_l = ctx.field.length / 2.0
        half_w = ctx.field.width / 2.0 - 0.3
        tx = clamp(tx, -half_l + 0.3, half_l)
        ty = clamp(ty, -half_w, half_w)
        self.move_to_position((tx, ty))

    def take_kickoff(self, kick_target: tuple[float, float] | None = None) -> None:
        """我方开球/重开:未就位则绕到球后待命(避球不碰),就位后接近并踢。"""
        ball = self.context.ball if self.context is not None else None
        if ball is None or self.pose is None:
            self.stop()
            return
        if kick_target is None:
            kick_target = opponent_goal(self.context)
        kick_dir = angle_to(ball.x, ball.y, *kick_target)
        cos_k, sin_k = math.cos(kick_dir), math.sin(kick_dir)
        rel_x, rel_y = self.pose.x - ball.x, self.pose.y - ball.y
        behind = rel_x * cos_k + rel_y * sin_k          # <0 在球后方(己方侧)
        lateral = abs(-rel_x * sin_k + rel_y * cos_k)
        if behind > KICKOFF_FRONT_MARGIN or lateral > KICKOFF_LATERAL_TOL:
            stage = (
                ball.x - cos_k * KICKOFF_STAGE_M,
                ball.y - sin_k * KICKOFF_STAGE_M,
            )
            self.release_kick()
            self.walk_to(stage, face=kick_dir, avoid_ball=True)
        else:
            self.attack(kick_target)

    def move_to_position(self, target: tuple[float, float] | None) -> None:
        """走到站位点(支援/防守/避让),面向球,避球+避机器人。"""
        if target is None:
            self.stop()
            return
        face = None
        ball = self.context.ball if self.context is not None else None
        if ball is not None and self.pose is not None:
            face = angle_to(self.pose.x, self.pose.y, ball.x, ball.y)
        self.release_kick()
        self.walk_to(target, face=face, avoid_ball=True, avoid_robots=True)

    @staticmethod
    def _angular(err: float) -> float:
        return clamp(ANGULAR_GAIN * err, -MAX_ANGULAR, MAX_ANGULAR)
