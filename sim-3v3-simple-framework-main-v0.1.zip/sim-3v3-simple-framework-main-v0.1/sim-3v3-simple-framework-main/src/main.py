"""SoccerSim 策略入口 —— 比赛策略主逻辑都在这里,改打法就改这个文件。

结构(由浅入深):
- main.py(本文件):比赛策略。play() 按 Phase 状态机分派到 _act_*;各 _act_* 选出
  attacker(离球最近)并直接调 player 动作。
- player.py:Player 控制 handle + 高层动作(attack / take_kickoff /
  move_to_position / walk_to);想加拐棍/技术动作直接改它。
- utils/:走位/几何/避障工具(opponent_goal / dist / angle_to ...)。
- framework/:平台管线,用户不改。

改打法主要改本文件:Phase 状态机、各 _act_* 行为、站位公式。
"""

from __future__ import annotations

import logging
import math
from enum import Enum

from booster_agent_framework import AgentBase

from .framework.agent import SoccerAgentMixin
from .framework.types import KICKING_TEAM_NONE, Context, GameState, SetPlay
from .param import *
from .player import Player
from .utils import angle_to, dist, opponent_goal, own_goal


_log = logging.getLogger(__name__)


# ======================================================================
# Phase 状态机 —— 比赛阶段分类
# ======================================================================


class Phase(Enum):
    """比赛阶段。顶层状态机,决定当前是正常拼抢/开球/定位球/准备/停止。"""
    NORMAL = "normal"              # PLAYING 正常拼抢
    OUR_KICKOFF = "our_kickoff"    # 我方开球(SET+PLAYING 初期,take_kickoff)
    OPP_KICKOFF = "opp_kickoff"    # 对方开球(避让)
    OUR_SET_PLAY = "our_set_play"  # 我方定位球(任意球/角球/球门球)
    OPP_SET_PLAY = "opp_set_play"  # 对方定位球(避让)
    READY = "ready"                # READY 走位
    STOPPED = "stopped"            # SET(非开球重开) / INITIAL / FINISHED / stopped


def get_phase(context: Context) -> Phase:
    """根据裁判机状态判断当前比赛阶段。"""
    g = context.game
    if g is None:
        return Phase.STOPPED

    state = g.state

    # READY:走 ready 位
    if state == GameState.READY:
        return Phase.READY

    # PLAYING:正常拼抢 or 开球/定位球执行中
    if state == GameState.PLAYING and not g.stopped:
        # 定位球:set_play != NONE,kicking_team 指示哪方
        if g.set_play != SetPlay.NONE and g.kicking_team != KICKING_TEAM_NONE:
            our_team = context.team_id
            if g.kicking_team == our_team:
                return Phase.OUR_SET_PLAY
            else:
                return Phase.OPP_SET_PLAY

        # 开球:secondary_time > 0(倒计时窗口),kicking_team 指示哪方
        if g.secondary_time > 0 and g.kicking_team != KICKING_TEAM_NONE:
            our_team = context.team_id
            if g.kicking_team == our_team:
                return Phase.OUR_KICKOFF
            else:
                return Phase.OPP_KICKOFF

        # 正常拼抢
        return Phase.NORMAL

    # SET / INITIAL / FINISHED / stopped:站定
    return Phase.STOPPED

def get_set_play_type(context: Context) -> SetPlay:
    """当前生效的定位球类型;无定位球(或无裁判机数据)时返回 ``SetPlay.NONE``。

    直接读裁判机的 ``set_play`` 字段,不区分是哪方主罚 —— 哪方由 :func:`get_phase`
    (OUR_SET_PLAY / OPP_SET_PLAY)判定。这里只回答"是什么类型的定位球"。

    共 7 种可能返回值(见 framework.types.SetPlay):
    - ``NONE``:无定位球(正常比赛/开球等)
    - ``DIRECT_FREE_KICK``:直接任意球(可直接射门得分)
    - ``INDIRECT_FREE_KICK``:间接任意球(须先触碰他人才能进球)
    - ``PENALTY_KICK``:点球
    - ``THROW_IN``:界外球(踢入)
    - ``GOAL_KICK``:球门球
    - ``CORNER_KICK``:角球
    """
    g = context.game
    if g is None:
        return SetPlay.NONE
    return g.set_play


# ======================================================================
# Agent 入口
# ======================================================================


class SoccerSimAgent(SoccerAgentMixin, AgentBase):
    """3v3 SoccerSim agent。"""

    player_class = Player

    def init_store(self, store) -> None:
        _log.info("init_store called")
        store.prev_phase = None       # 上一帧 phase,用于检测 phase 跳变(边沿)
        store.cur_phase = None
        store.kickoff_taker = None    # 锁定的开球主罚球员 id(每次进入开球时重选)
        store.normal_attacker = None

    @staticmethod
    def play(context: Context, players: list[Player], store) -> None:
        phase = get_phase(context)
        store.prev_phase = store.cur_phase
        store.cur_phase = phase

        # 画可视化(每帧)
        _analyze_and_draw(context, players, store)

        # 当前 phase 以 label 画在场外。
        from .framework import debugdraw
        g = context.game
        game_state = g.state.value if g is not None else "none"
        set_play = g.set_play.value if g is not None else "none"
        secondary_time = g.secondary_time if g is not None else 0.0
        debugdraw.text(
            0.0, context.field.width / 2.0 + 0.2,
            f"phase={phase.value} state={game_state} set={set_play} secondary={secondary_time:.1f}",
            rgb=(1.0, 1.0, 0.0), ns="phase",
        )

        # 活性自理 + 过滤出本帧可行动的球员。
        # ensure_ready:摔倒起身 / 切 walk 模式(异步,不产生移动);被罚下的也做,
        # 这样解罚后能立刻投入。被罚下或未就绪的不参与分派(也不进角色分配,避免把
        # 动不了的人选成 attacker 导致该帧无人进攻)。
        active: list[Player] = []
        for p in players:
            ready = p.ensure_ready()
            if p.is_penalized:
                p.action = "penalized"     # 罚下:可起身/切模式,但不能移动
                p.stop()
            elif not ready:
                p.action = "fallen" if p.is_fallen else "switching_mode"
            elif p.pose is None:
                p.action = "no_pose"       # 自己位置未知:不参与分派(下游按 pose 已知处理)
                p.stop()
            else:
                active.append(p)

        # 按 phase 对整队分派一次(角色分配等全队计算只在 _act_* 里算一次)。
        if phase == Phase.NORMAL:
            _act_normal(context, active, store)
        elif phase == Phase.OUR_KICKOFF:
            _clear_normal_sticky(store)
            _act_our_kickoff(context, active, store)
        elif phase == Phase.OPP_KICKOFF:
            _clear_normal_sticky(store)
            _act_opp_kickoff(context, active)
        elif phase == Phase.OUR_SET_PLAY:
            _clear_normal_sticky(store)
            _act_our_set_play(context, active, store)
        elif phase == Phase.OPP_SET_PLAY:
            _clear_normal_sticky(store)
            _act_opp_set_play(context, active, store)
        elif phase == Phase.READY:
            _clear_normal_sticky(store)
            _act_ready(context, active)
        elif phase == Phase.STOPPED:
            _clear_normal_sticky(store)
            for p in active:
                p.action = "stopped"
                p.stop()

        # 队员可视化统一在最后画一遍:覆盖所有球员(含判罚/未就绪/STOPPED),
        # 修复 SET 等状态下红球/标签消失的问题。
        for p in players:
            _draw_teammate_marker(p)


def _clear_normal_sticky(store) -> None:
    store.normal_attacker = None


def _player_dist_to_ball(context: Context, p: Player) -> float:
    """球员到球当前位置的距离。"""
    ball = context.ball
    return (
        dist(p.pose.x, p.pose.y, ball.x, ball.y) + _fallen_time_cost(p)
        if ball is not None else math.inf
    )


def _fallen_time_cost(p: Player) -> float:
    return FALLEN_COST if p.is_fallen else 0.0


def _select_closest_attacker(
    context: Context,
    players: list[Player],
    preferred_id: int | None = None,
) -> Player:
    """选到球距离最小的球员。

    ``players`` 非空、已就绪、pose 已知。normal 与开球共用。
    """
    ranked = [(p, _player_dist_to_ball(context, p)) for p in players]
    best, best_dist = min(ranked, key=lambda item: item[1])
    preferred = next((item for item in ranked if item[0].id == preferred_id), None)
    if (
        preferred is not None
        and preferred[1] <= best_dist + ATTACKER_KEEP_DIST_MARGIN_M
    ):
        return preferred[0]
    return best


def _act_normal(context: Context, players: list[Player], store) -> None:
    """NORMAL:距球最近者 attack,剩下人里离己方门最近者 guard,其余 support。

    ``players`` 是本帧可行动球员(已就绪、pose 已知),这里直接挑角色并执行。
    """
    if not players:
        return

    attacker = _select_closest_attacker(
        context, players, getattr(store, "normal_attacker", None),
    )
    store.normal_attacker = attacker.id
    attacker.action = "attack"
    attacker.attack()

    # guard:剩下人里离己方门最近者(如还有人)
    rest = [p for p in players if p is not attacker]
    if rest:
        gx, gy = own_goal(context)
        guard = min(rest, key=lambda p: dist(p.pose.x, p.pose.y, gx, gy))
        guard.guard()  
        rest = [p for p in rest if p is not guard]

    # support:其余全部
    for p in rest:
        p.action = "support"
        p.support()


def _act_our_kickoff(context: Context, players: list[Player], store) -> None:
    """OUR_KICKOFF:锁定距离最小者开球,剩下人里离己方门最近者 guard,其余 support。"""
    if not players:
        return

    active_ids = {p.id for p in players}
    if store.prev_phase != Phase.OUR_KICKOFF or store.kickoff_taker not in active_ids:
        # 进入开球阶段，重新选择开球球员
        store.kickoff_taker = _select_closest_attacker(context, players).id

    attacker_id = store.kickoff_taker
    attacker = next((p for p in players if p.id == attacker_id), None)
    if attacker is None:
        return

    attacker.action = "kickoff"
    attacker.kick(0.1, KICK_POWER_KICKOFF)   # 中线开球力度减轻至 4.5

    rest = [p for p in players if p is not attacker]
    if rest:
        gx, gy = own_goal(context)
        guard = min(rest, key=lambda p: dist(p.pose.x, p.pose.y, gx, gy))
        guard.guard()
        rest = [p for p in rest if p is not guard]

    for p in rest:
        p.action = "stay"
        p.stop()


def _act_opp_kickoff(context: Context, players: list[Player]) -> None:
    """对方开球:一人守门,其余人站到中圈外固定点等待。

    requirement 1:对方/系统开球时**不触控球**,且与球保持 >= ``BALL_CLEARANCE_OPP_RESTART_M``
    (0.5m)。非守门员统一经 :meth:`Player.hold_away_from_ball` 走位,保证既不踢球也与球留出
    安全距离,避免 ILLEGAL_POSITIONING 判罚。
    """
    if not players:
        return
    gx, gy = own_goal(context)
    guard = min(players, key=lambda p: dist(p.pose.x, p.pose.y, gx, gy))
    guard.guard()

    rest = [p for p in players if p is not guard]
    r = context.field.circle_radius
    slots = [(-r - 0.5, 0.0), (-r - 2.0, 0.5)]
    for p, target in zip(rest, slots):
        p.action = "opp_kickoff:ready"
        p.hold_away_from_ball(target)


def _select_free_robot(
    context: Context, players: list[Player], excluded_id: int,
) -> Player | None:
    """从其余球员里选“自由机器人”(接应/射门):优先离对方门最近的。"""
    rest = [p for p in players if p.id != excluded_id]
    if not rest:
        return None
    gx, gy = opponent_goal(context)
    return min(rest, key=lambda p: dist(p.pose.x, p.pose.y, gx, gy))


def _act_our_set_play(context: Context, players: list[Player], store) -> None:
    """OUR_SET_PLAY:我方边线球 / 角球的主罚与接应套路。

    - 角球:对方半场角球 → 主罚球员调力直接射向对方球门中心;己方半场角球 → 传中。
    - 边线球:主罚球员先停顿 0.4s 调整好后传给自由机器人;己方半场边线球时自由机器人
      向中区移动,对方半场边线球时自由机器人向球门方向跑位,接球后判断遮挡再射门。
    - 其余类型(任意球 / 球门球等)→ 沿用正常拼抢。
    """
    if not players:
        return

    set_play = get_set_play_type(context)
    ball = context.ball

    if set_play not in (SetPlay.THROW_IN, SetPlay.CORNER_KICK) or ball is None:
        _act_normal(context, players, store)
        return

    kicker = _select_closest_attacker(context, players)
    free = _select_free_robot(context, players, kicker.id)
    in_opp_half = ball.x > 0.0
    taken = {kicker.id, free.id if free else None}

    if set_play == SetPlay.CORNER_KICK:
        if in_opp_half:
            # 对方半场角球:主罚调力直接射向对方球门中心。
            kicker.action = "corner:shoot"
            kicker.approach_and_kick(opponent_goal(context), KICK_POWER_CORNER_SHOT)
            if free is not None:
                # 自由机器人到门前抢二点(接补射)。
                gx, gy = opponent_goal(context)
                free.action = "corner:rebound"
                free.move_to_position((gx - 0.8, gy))
        else:
            # 己方半场角球:传中给向球门方向跑位的自由机器人。
            free_target = _free_robot_attack_point(context, ball)
            kicker.action = "corner:cross"
            kicker.approach_and_kick(free_target, KICK_POWER_SET_PLAY_PASS)
            if free is not None:
                free.action = "corner:receive"
                free.move_to_position(free_target)
        _assign_extras(context, players, taken)
        return

    # 边线球:主罚先停顿 0.4s 调整好,再把球传给自由机器人的目标位置。
    if in_opp_half:
        # 对方半场:自由机器人向球门方向跑位,接球后自行判断遮挡再射门。
        free_target = _free_robot_attack_point(context, ball)
        free_action = "throwin:receive"
    else:
        # 己方半场:自由机器人向中区移动接应。
        free_target = (MID_AREA_X_M, 0.0)
        free_action = "throwin:to_mid"

    kicker.action = "throwin:pass"
    kicker.approach_and_kick(free_target, KICK_POWER_SET_PLAY_PASS)
    if free is not None:
        free.action = free_action
        free.move_to_position(free_target)
    _assign_extras(context, players, taken)


def _free_robot_point(
    context: Context,
    free: Player | None,
    fallback: tuple[float, float] | None = None,
) -> tuple[float, float]:
    """自由机器人当前(或期望)的传球落点。"""
    if free is not None and free.pose is not None:
        return (free.pose.x, free.pose.y)
    if fallback is not None:
        return fallback
    gx, gy = opponent_goal(context)
    return (gx, gy)


def _free_robot_attack_point(
    context: Context, ball,
) -> tuple[float, float]:
    """对方半场边线球:自由机器人向球门方向跑位点(球→门连线上、离球一段距离)。"""
    gx, gy = opponent_goal(context)
    d = math.hypot(gx - ball.x, gy - ball.y)
    if d < 1e-6:
        return (gx, gy)
    ux, uy = (gx - ball.x) / d, (gy - ball.y) / d
    approach = min(FREE_ROBOT_GOAL_APPROACH_M, d)
    return (ball.x + ux * approach, ball.y + uy * approach)


def _assign_extras(
    context: Context, players: list[Player], taken_ids: set,
) -> None:
    """把未被分配为主罚/自由机器人的球员按 守门 + 支援 兜底(避免原地不动/漏人)。"""
    rest = [p for p in players if p.id not in taken_ids]
    if not rest:
        return
    gx, gy = own_goal(context)
    guard = min(rest, key=lambda p: dist(p.pose.x, p.pose.y, gx, gy))
    guard.guard()
    rest = [p for p in rest if p is not guard]
    for p in rest:
        p.action = "set_play:support"
        p.support()


def _act_opp_set_play(context: Context, players: list[Player], store) -> None:
    """对方定位球 / 系统摆球:不触控球,保持防守站位。

    requirement 1 同样约束系统摆球:对方主罚期间我们**不去碰球**。一人守门,其余人沿
    "球→己方门"方向退防并保持 >= ``BALL_CLEARANCE_OPP_RESTART_M``(0.5m),既封堵又不
    违规触球。
    """
    if not players:
        return
    ball = context.ball
    gx, gy = own_goal(context)
    guard = min(players, key=lambda p: dist(p.pose.x, p.pose.y, gx, gy))
    guard.guard()

    rest = [p for p in players if p is not guard]
    if ball is None:
        for p in rest:
            p.action = "opp_set:hold"
            p.hold_away_from_ball(None)
        return

    # 沿 球→己方门 方向分层退防,hold_away_from_ball 会把落点推出球的 0.5m 安全圈。
    goal_dir = math.atan2(gy - ball.y, gx - ball.x)
    half_l = context.field.length / 2.0
    half_w = context.field.width / 2.0 - 0.3
    for i, p in enumerate(rest):
        along = 2.0 + i * 1.5
        tx = ball.x + math.cos(goal_dir) * along
        ty = ball.y + math.sin(goal_dir) * along
        tx = max(-half_l + 0.3, min(half_l, tx))
        ty = max(-half_w, min(half_w, ty))
        p.action = "opp_set:hold"
        p.hold_away_from_ball((tx, ty))


def _act_ready(context: Context, players: list[Player]) -> None:
    """READY:各自走 ready 位。"""
    game = context.game
    our_kickoff = game is not None and game.kicking_team == context.team_id
    field = context.field
    # 我方开球：优先级站位：(-中圈半径, 0), (我方 goal area 中心点，0)， （0， 中圈半径）
    if our_kickoff:
        if len(players) >= 1:
            p1 = players[0]
            p1.action = "ready"
            p1.walk_to(
                (-field.circle_radius, 0.0),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )
        if len(players) >= 2:
            p2 = players[1]
            p2.action = "ready"
            p2.walk_to(
                (-field.length / 2.0 + field.goal_area_length, 0.0),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )
        if len(players) >= 3:
            p3 = players[2]
            p3.action = "ready"
            p3.walk_to(
                (-0.5, field.circle_radius + 2),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )
    # 对方开球：优先级站位：(-中圈半径 - 0.5, 0), (我方 goal area 中心点，0)， （我方禁区线中心点， 0)
    else:
        if len(players) >= 1:
            p1 = players[0]
            p1.action = "ready"
            p1.walk_to(
                (-field.circle_radius - 0.5, 0.0),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )
        if len(players) >= 2:
            p2 = players[1]
            p2.action = "ready"
            p2.walk_to(
                (-field.length / 2.0 + field.goal_area_length, 0.0),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )
        if len(players) >= 3:
            p3 = players[2]
            p3.action = "ready"
            p3.walk_to(
                (-field.length / 2.0 + field.penalty_area_length, 0.0),
                face=0.0,
                avoid_ball=True,
                avoid_robots=True,
            )



# ======================================================================
# 战场可视化 —— 显示球位置 + 球员到球的距离,画到 ROS 可视化
# ======================================================================

def _draw_teammate_marker(p: Player) -> None:
    """我方队员可视化:红色。踢球中→方块,否则→球体。

    每帧对所有球员统一调用(不受 phase/判罚/就绪影响)。标签两行:
    - 上:编号 + 当前高层动作(``p.action``),踢球中追加 ``[KICK]``。
    - 通过形状(方块 vs 球体)再次区分是否进入 kick 状态。
    """
    from .framework import debugdraw

    if p.pose is None:
        return
    red = (1.0, 0.2, 0.2)
    if p.is_kicking:
        debugdraw.cube(p.pose.x, p.pose.y, rgb=red, scale=0.38, ns="teammate")
    else:
        debugdraw.point(p.pose.x, p.pose.y, rgb=red, scale=0.3, ns="teammate")
    kick_tag = " [KICK]" if p.is_kicking else ""
    label = f"{p.id}:{p.action}{kick_tag}"
    debugdraw.text(p.pose.x, p.pose.y, label, rgb=(1.0, 0.9, 0.6), ns="teammate_id")


def _analyze_and_draw(context: Context, players: list[Player], store) -> None:
    """每帧:计算球员到球的距离,画可视化。

    不再依赖 analysis 模块;距离改为基于球当前位置。
    """
    from .framework import debugdraw

    ball = context.ball

    # 球不可见:无可视化
    if ball is None:
        return

    # 1. 画球当前位置(绿色点)
    debugdraw.point(ball.x, ball.y, rgb=(0.0, 1.0, 0.0), scale=0.2, ns="ball_current")

    # 2. 球员到球的距离:我方(红标签)+ 敌方(蓝标签)
    for p in players:
        if p.pose is None:
            continue
        d = dist(p.pose.x, p.pose.y, ball.x, ball.y)
        debugdraw.text(
            p.pose.x + 0.3, p.pose.y - 0.3, f"{d:.1f}m",
            rgb=(1.0, 0.6, 0.6), ns="dist_ours",
        )
    for r in context.opponents.values():
        if r.pose is None:
            continue
        d = dist(r.pose.x, r.pose.y, ball.x, ball.y)
        debugdraw.text(
            r.pose.x + 0.3, r.pose.y - 0.3, f"{d:.1f}m",
            rgb=(0.6, 0.6, 1.0), ns="dist_opp",
        )

